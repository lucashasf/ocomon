<?php 

	include ("../../includes/classes/AuthNew.class.php"); 
	include ("../../includes/functions/functions.php");
	include ("../../includes/functions/dbFunctions.php");
	include ("../../includes/config.inc.php");
	include ("../../includes/versao.php");
 	include ("../../includes/languages/".LANGUAGE.""); //TEMPORARIAMENTE
 	include ("../../includes/queries/queries.php");
	
	require  "../../api/ocomon_api/vendor/autoload.php";

?>
