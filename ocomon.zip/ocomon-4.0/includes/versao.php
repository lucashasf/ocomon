<?php 
//Versao do Sistema
define ( "VERSAO", "4.0");

?>
